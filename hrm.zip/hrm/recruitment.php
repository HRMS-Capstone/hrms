<?php
// Database connection
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "hrm"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cfname = $_POST['cfname'];
    $clname = $_POST['clname'];
    $email = $_POST['email'];
    $status = $_POST['status'];
    $date_applied = $_POST['date_applied'];

    $sql = "INSERT INTO recruitment (cfname, clname, email, status, date_applied) VALUES ('$cfname', '$clname', '$email', '$status', '$date_applied')";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Recruitment data added successfully');</script>";
    } else {
        echo "<script>alert('Error: " . $sql . " - " . $conn->error . "');</script>";
    }
}

// Fetch data from the database
$sql = "SELECT * FROM recruitment";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recruitment</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    display: flex;
    min-height: 100vh; /* Ensure full height of the page */
    margin: 0;
    padding: 0;
}

.sidebar {
    position: fixed; /* Make the sidebar fixed */
    top: 0;
    left: 0;
    width: 250px;
    background: black;
    color: white;
    padding: 20px;
    height: 100vh; /* Full height of the screen */
    display: flex;
    flex-direction: column;
    justify-content: center; /* Center the content vertically */
    align-items: center; /* Center the items horizontally */
    text-align: center; /* Optional, centers the text */
    box-sizing: border-box; /* Ensures padding is included in width and height */
}

.sidebar h2 {
    margin-top: 0;
    font-size: 24px;
    color: white;
}

.sidebar img {
    width: 100px;
    height: 100px;
    border-radius: 50%; /* Circle the logo */
    object-fit: cover;
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    margin: 10px 0;
    text-decoration: none;
    color: #28a745; /* Green color for links */
    font-size: 18px; /* Adjust font size */
}

.sidebar a:hover {
    text-decoration: underline;
    color: #61ff61; /* Lighter green on hover */
}

.main-content {
    margin-left: 250px; /* Leave space for the fixed sidebar */
    flex: 1;
    padding: 20px;
    background-color: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.logout {
    /*background-color: #dc3545; */
    /*color: white;*/
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 20px;
}

.logout:hover {
    background-color: #c82333;
}

.chart-container {
    position: relative;
    margin: auto;
    height: 40vh;
    width: 80vw;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: left;
}

th {
    background-color: #28a745;
    color: white;
}

tr:hover {
    background-color: #f1f1f1;
}

    </style>
</head>
<body>
        <h1>Recruitment Form</h1>
        <form method="POST" action="recruitment.php">
            <label for="cfname">Candidate First Name:</label><br>
            <input type="text" id="cfname" name="cfname" required><br><br>
            <label for="clname">Candidate Last Name:</label><br>
            <input type="text" id="clname" name="clname" required><br><br>
            <label for="email">Email:</label><br>
            <input type="text" id="email" name="email" required><br><br>

            <label for="status">Status:</label><br>
            <select id="status" name="status" required>
                <option value="Applied">Applied</option>
                <option value="Interviewed">Interviewed</option>
                <option value="Hired">Hired</option>
                <option value="Rejected">Rejected</option>
            </select><br><br>

            <label for="date_applied">Date Applied:</label><br>
            <input type="date" id="date_applied" name="date_applied" required><br><br>

            <button type="submit">Submit</button>
        </form>

        <h2>Recruitment Records</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Candidate First Name</th>
                    <th>Candidate Last Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <th>Date Applied</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['cfname'] . "</td>";
                        echo "<td>" . $row['clname'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>" . $row['status'] . "</td>";
                        echo "<td>" . $row['date_applied'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No records found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>
