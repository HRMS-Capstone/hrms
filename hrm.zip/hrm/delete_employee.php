<?php
// Database connection
$host = 'localhost';
$db = 'hrm';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get employee ID from URL parameter and validate it
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $employeeId = (int)$_GET['id']; // Cast to integer to prevent malicious input

    // Begin transaction to ensure both deletions happen together
    $conn->begin_transaction();

    try {
        // Delete related payroll records
        $sqlDeletePayroll = "DELETE FROM payroll WHERE employee_id = ?";
        $stmtPayroll = $conn->prepare($sqlDeletePayroll);
        $stmtPayroll->bind_param("i", $employeeId);
        $stmtPayroll->execute();
        $stmtPayroll->close();

        // Delete the employee record
        $sqlDeleteEmployee = "DELETE FROM employees WHERE id = ?";
        $stmtEmployee = $conn->prepare($sqlDeleteEmployee);
        $stmtEmployee->bind_param("i", $employeeId);
        $stmtEmployee->execute();
        $stmtEmployee->close();

        // Commit transaction
        $conn->commit();

        // Redirect after deletion
        header('Location: employee_list.php?message=Employee deleted successfully');
        exit();  // Make sure to stop further execution after redirection

    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        echo 'Error deleting employee: ' . $e->getMessage();
    }
} else {
    // Handle case where the ID is not provided or invalid
    echo 'Invalid or missing employee ID.';
}

$conn->close();
?>
