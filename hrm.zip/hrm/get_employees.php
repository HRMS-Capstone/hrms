<?php   
// Database connection details
$host = 'localhost';
$db = 'hrm';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all employees from the database
$sql = "SELECT id, first_name, last_name, email, job_title FROM employees";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo '<h2>Employees List</h2>';
    echo '<table border="1">';
    echo '<thead><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Email</th><th>Job Title</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    
    while ($row = $result->fetch_assoc()) {
        $employeeId = $row['id'];
        $employeeName = htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); // Full name of the employee
        
        echo '<tr>';
        echo '<td>' . htmlspecialchars($row['id']) . '</td>';
        echo '<td>' . htmlspecialchars($row['first_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['last_name']) . '</td>';
        echo '<td>' . htmlspecialchars($row['email']) . '</td>';
        echo '<td>' . htmlspecialchars($row['job_title']) . '</td>';
        // Action buttons for Edit and Delete
        echo '<td>';
        echo '<a href="edit_employee.php?id=' . $employeeId . '" class="btn-edit">Edit</a> ';
        echo '<a href="delete_employee.php?id=' . $employeeId . '" class="btn-delete" onclick="return confirm(\'Are you sure you want to delete ' . $employeeName . '?\')">Delete</a>';
        echo '</td>';
        echo '</tr>';
    }
    
    echo '</tbody>';
    echo '</table>';
} else {
    echo 'No employees found.';
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $job_title = $_POST['job_title'];

    // Prepare the SQL query to insert the new employee
    $sql = "INSERT INTO employees (first_name, last_name, email, job_title) VALUES (?, ?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("ssss", $first_name, $last_name, $email, $job_title);
        
        // Execute the query
        if ($stmt->execute()) {
            // Redirect to refresh the page after insertion
            if ($_SERVER['HTTP_X_REQUESTED_WITH'] == 'XMLHttpRequest') {
                echo json_encode(['success' => true]);
            } else {
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            }
        } else {
            echo json_encode(['success' => false, 'error' => $stmt->error]);
        }

        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }
}
?>

<!-- Add Employee Button -->
<style>
    .plus-button {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: #28a745;
        color: white;
        font-size: 24px;
        padding: 15px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
    }
    .plus-button:hover {
        background-color: #218838;
    }

    /* Modal styles */
    .modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
    }
    .modal-content {
        background-color: white;
        padding: 20px;
        border-radius: 8px;
        width: 400px;
    }
    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }
    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>

<!-- Plus Button -->
<button class="plus-button" onclick="openModal()">+</button>

<!-- Modal for Add Employee -->
<div id="employeeModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h2>Add Employee</h2>
        <form id="employeeForm">
            <label for="first_name">First Name:</label><br>
            <input type="text" name="first_name" required><br><br>

            <label for="last_name">Last Name:</label><br>
            <input type="text" name="last_name" required><br><br>

            <label for="email">Email:</label><br>
            <input type="email" name="email" required><br><br>

            <label for="job_title">Job Title:</label><br>
            <input type="text" name="job_title" required><br><br>

            <button type="button" onclick="submitForm()">Add Employee</button>
        </form>
    </div>
</div>

<script>
    // Open the modal
    function openModal() {
        document.getElementById("employeeModal").style.display = "flex";
    }

    // Close the modal
    function closeModal() {
        document.getElementById("employeeModal").style.display = "none";
    }

    // Close modal if clicked outside
    window.onclick = function(event) {
        if (event.target == document.getElementById("employeeModal")) {
            closeModal();
        }
    }

    // AJAX form submission
    function submitForm() {
        var form = document.getElementById("employeeForm");
        var formData = new FormData(form);

        var xhr = new XMLHttpRequest();
        xhr.open("POST", "", true);
        xhr.onload = function () {
            if (xhr.status == 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    alert("Employee added successfully!");
                    location.reload(); // Reload the page to show the new employee
                } else {
                    alert("Error adding employee: " + response.error);
                }
            } else {
                alert("Error with the request.");
            }
        };
        xhr.send(formData);
    }
</script>