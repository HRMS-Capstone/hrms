<?php
// Database connection
$servername = "localhost"; // Replace with your server name
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "hrm"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the form submission for position update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_position'])) {
    if (isset($_POST['position'])) {  // Check if 'position' is set
        $position = $_POST['position'];
        // Process the position update logic here
        // For example, you can update the candidate's position in the database
    } else {
        // Handle the case where 'position' is not set
        echo "Position is not set.";
    }
}


// Handle status update (Hired/Rejected)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $candidate_id = $_POST['candidate_id'];
    $status = $_POST['status'];

    $sql = "UPDATE recruitment SET status = '$status' WHERE id = $candidate_id";
    if ($conn->query($sql) === TRUE) {
        if ($status === 'Hired') {
            // Optionally, add to the employees table
            $result = $conn->query("SELECT * FROM recruitment WHERE id = $candidate_id");
            $candidate = $result->fetch_assoc();
            $fname = $candidate['cfname'];
            $lname = $candidate['clname'];
            $email = $candidate['email'];

            $conn->query("INSERT INTO employees (fname, lname, email, date_hired) VALUES ('$fname', '$lname', '$email', NOW())");
        }
        echo "<script>alert('Status updated successfully');</script>";
    } else {
        echo "<script>alert('Error updating status: " . $conn->error . "');</script>";
    }
}

// Fetch shortlisted candidates
$sql = "SELECT * FROM recruitment WHERE status IN ('Interviewed')";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hiring</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    display: flex;
    min-height: 100vh; /* Ensure full height of the page */
    margin: 0;
    padding: 0;
}

.sidebar {
    position: fixed; /* Make the sidebar fixed */
    top: 0;
    left: 0;
    width: 250px;
    background: black;
    color: white;
    padding: 20px;
    height: 100vh; /* Full height of the screen */
    display: flex;
    flex-direction: column;
    justify-content: center; /* Center the content vertically */
    align-items: center; /* Center the items horizontally */
    text-align: center; /* Optional, centers the text */
    box-sizing: border-box; /* Ensures padding is included in width and height */
}

.sidebar h2 {
    margin-top: 0;
    font-size: 24px;
    color: white;
}

.sidebar img {
    width: 100px;
    height: 100px;
    border-radius: 50%; /* Circle the logo */
    object-fit: cover;
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    margin: 10px 0;
    text-decoration: none;
    color: #28a745; /* Green color for links */
    font-size: 18px; /* Adjust font size */
}

.sidebar a:hover {
    text-decoration: underline;
    color: #61ff61; /* Lighter green on hover */
}

.main-content {
    margin-left: 250px; /* Leave space for the fixed sidebar */
    flex: 1;
    padding: 20px;
    background-color: white;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.logout {
    /*background-color: #dc3545; */
    /*color: white;*/
    padding: 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 20px;
}

.logout:hover {
    background-color: #c82333;
}

.chart-container {
    position: relative;
    margin: auto;
    height: 40vh;
    width: 80vw;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: left;
}

th {
    background-color: #28a745;
    color: white;
}

tr:hover {
    background-color: #f1f1f1;
}

    </style>
</head>
<body>
        <h1>Hiring Candidates</h1>
        <h2>Shortlisted Candidates</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Candidate First Name</th>
                    <th>Candidate Last Name</th>
                    <th>Email</th>
                    <th>Position</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['id'] . "</td>";
                        echo "<td>" . $row['cfname'] . "</td>";
                        echo "<td>" . $row['clname'] . "</td>";
                        echo "<td>" . $row['email'] . "</td>";
                        echo "<td>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='position' value='" . $row['id'] . "'> <!-- hidden field -->
                                <select name='position'> <!-- select dropdown with 'name' as 'position' -->
                                    <option value='It Officer'>IT Officer</option>
                                    <option value='HR Staff'>HR Staff</option>
                                </select>
                            </form>
                        </td>";
                        echo "<td>" . $row['status'] . "</td>";
                        echo "<td>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='candidate_id' value='" . $row['id'] . "'>
                                <select name='status'>
                                    <option value='Hired'>Hired</option>
                                    <option value='Rejected'>Rejected</option>
                                </select>
                                <button type='submit' name='update_status'>Update</button>
                            </form>
                        </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No shortlisted candidates found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
$conn->close();
?>
